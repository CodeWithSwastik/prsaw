joke_response_keys = {"error", "category", "type", "flags", "id", "safe", "lang"}
